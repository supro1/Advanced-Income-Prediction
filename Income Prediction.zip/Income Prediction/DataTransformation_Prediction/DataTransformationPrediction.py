from datetime import datetime
from os import listdir
import pandas
import numpy as np
from application_logging.logger import App_Logger


class dataTransformPredict:



     def __init__(self):
          self.goodDataPath = "Prediction_Raw_Files_Validated/Good_Raw"
          self.logger = App_Logger()


     def replaceMissingWithNull(self):


          try:
               log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath+"/" + file)
                    csv['country'] = csv['country'].replace(' ?', np.nan)
                    csv['workclass'] = csv['workclass'].replace(' ?', np.nan)
                    csv['occupation'] = csv['occupation'].replace(' ?', np.nan)
                    csv.dropna(how='any', inplace=True)


                    csv.to_csv(self.goodDataPath+ "/" + file, index=None, header=True)
                    self.logger.log(log_file," %s: Missing Value Transformed successfully!!" % file)
               #log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")

          except Exception as e:
               self.logger.log(log_file, "Missing Value Transformation failed because:: %s" % e)
               #log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
               raise e
          log_file.close()

     def convertSexToInt(self):

          log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
          try:
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath+"/" + file)

                    csv['sex'] = csv['sex'].map({' Male': 1, ' Female': 0}).astype(int)

                    csv.to_csv(self.goodDataPath+ "/" + file, index=None, header=True)
                    self.logger.log(log_file," %s:  Sex Transformed successfully!!" % file)
               #log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")
          except Exception as e:
               self.logger.log(log_file, " Sex Transformation failed because:: %s" % e)
               #log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
          log_file.close()


     def convertMaritalStatusRelationshipRace(self):

          log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
          try:
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath + "/" + file)

                    csv['marital-status'] = csv['marital-status'].replace(
                         [' Divorced', ' Married-spouse-absent', ' Never-married', ' Separated', ' Widowed'], 'Single')
                    csv['marital-status'] = csv['marital-status'].replace([' Married-AF-spouse', ' Married-civ-spouse'],
                                                                        'Couple')
                    csv['marital-status'] = csv['marital-status'].map({'Couple': 0, 'Single': 1})

                    rel_map = {' Unmarried': 0, ' Wife': 1, ' Husband': 2, ' Not-in-family': 3, ' Own-child': 4,
                               ' Other-relative': 5}

                    csv['relationship'] = csv['relationship'].map(rel_map)

                    race_map = {' White': 0, ' Amer-Indian-Eskimo': 1, ' Asian-Pac-Islander': 2, ' Black': 3,
                                ' Other': 4}

                    csv['race'] = csv['race'].map(race_map)


                    csv.to_csv(self.goodDataPath + "/" + file, index=None, header=True)
                    self.logger.log(log_file, " %s: MaritalStatus, Relationship, Race Transformed successfully!!" % file)
               # log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")
          except Exception as e:
               self.logger.log(log_file, "SMaritalStatus, Relationship, Race Transformation failed because:: %s" % e)
               # log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
          log_file.close()

     def employmentConvert(self,x):
          if x['workclass'] == ' Federal-gov' or x['workclass'] == ' Local-gov' or x['workclass'] == ' State-gov':
               return 'govt'
          elif x['workclass'] == ' Private':
               return 'private'
          elif x['workclass'] == ' Self-emp-inc' or x['workclass'] == ' Self-emp-not-inc':
               return 'self_employed'
          else:
               return 'without_pay'

     def convertEmploymentCapitalGainLoss(self):

          log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
          try:
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath+"/" + file)

                    csv['employment_type']=csv.apply(self.employmentConvert, axis=1)
                    employment_map = {'govt': 0, 'private': 1, 'self_employed': 2, 'without_pay': 3}
                    csv['employment_type'] = csv['employment_type'].map(employment_map)

                    csv.loc[(csv['capital-gain'] > 0), 'capital-gain'] = 1
                    csv.loc[(csv['capital-gain'] == 0, 'capital-gain')] = 0

                    csv.loc[(csv['capital-loss'] > 0), 'capital-loss'] = 1
                    csv.loc[(csv['capital-loss'] == 0, 'capital-loss')] = 0

                    csv.to_csv(self.goodDataPath+ "/" + file, index=None, header=True)
                    self.logger.log(log_file," %s: Employment & Capital gain Transformed successfully!!" % file)
               #log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")
          except Exception as e:
               self.logger.log(log_file, "Employment & Capital Gain Transformation failed because:: %s" % e)
               #log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
          log_file.close()

     def convertCountryEducation(self):

          log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
          try:
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath+"/" + file)

                    csv.loc[csv['country'] != ' United-States', 'country'] = 'Non-US'
                    csv.loc[csv['country'] == ' United-States', 'country'] = 'US'
                    csv['country'] = csv['country'].map({'US': 1, 'Non-US': 0}).astype(int)

                    csv['education'] = csv['education'].apply(lambda item: item.strip())
                    csv['education'] = csv['education'].replace(
                         ['10th', '11th', '12th', '1st-4th', '5th-6th','7th-8th','9th','Preschool'], 1)
                    csv['education'] = csv['education'].replace(
                         ['HS-grad', 'Some-college', 'Assoc-voc', 'Assoc-acdm'], 2)
                    csv['education'] = csv['education'].replace(
                         ['Bachelors', 'Masters'], 3)
                    csv['education'] = csv['education'].replace(
                         ['Doctorate', 'Prof-school'], 4)

                    csv.to_csv(self.goodDataPath+ "/" + file, index=None, header=True)
                    self.logger.log(log_file," %s: ECountry & Education Transformed successfully!!" % file)
               #log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")
          except Exception as e:
               self.logger.log(log_file, "Country & Education Transformation failed because:: %s" % e)
               #log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
          log_file.close()

     def dropUnimportantColumn(self):

          log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
          try:
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath+"/" + file)

                    csv.drop(labels=['workclass','occupation'],axis=1,inplace=True)

                    csv.to_csv(self.goodDataPath+ "/" + file, index=None, header=True)
                    self.logger.log(log_file," %s: Column Drop Transformation done successfully!!" % file)
               #log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")
          except Exception as e:
               self.logger.log(log_file, "SColumn Drop Transformation failed because:: %s" % e)
               #log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
          log_file.close()

     def dataTypeConversion(self):

          log_file = open("Prediction_Logs/dataTransformLog.txt", 'a+')
          try:
               onlyfiles = [f for f in listdir(self.goodDataPath)]
               for file in onlyfiles:
                    csv = pandas.read_csv(self.goodDataPath+"/" + file)

                    csv=csv.astype({
                                      "age" : "int64",
                                      "fnlwgt": "int64",
                                      "education": "int64",
                                      "education-num": "int64",
                                      "marital-status": "int64",
                                      "relationship": "int64",
                                      "race": "int64",
                                      "sex": "int64",
                                      "capital-gain": "int64",
                                      "capital-loss": "int64",
                                      "hours-per-week": "int64",
                                      "country": "int64",
                                      "employment_type":"int64"
                                  })

                    csv.to_csv(self.goodDataPath+ "/" + file, index=None, header=True)
                    self.logger.log(log_file," %s: Data type conversion done successfully!!" % file)
               #log_file.write("Current Date :: %s" %date +"\t" + "Current time:: %s" % current_time + "\t \t" +  + "\n")
          except Exception as e:
               self.logger.log(log_file, "Data type conversion Transformation failed because:: %s" % e)
               #log_file.write("Current Date :: %s" %date +"\t" +"Current time:: %s" % current_time + "\t \t" + "Data Transformation failed because:: %s" % e + "\n")
               log_file.close()
          log_file.close()